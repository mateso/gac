
<iframe src="http://<?= $_SERVER['SERVER_NAME'] ?>/reportapp/GfsList?ClassificationDesc=<?= $classification_desc ?>&SubChapterDescr=<?= $subchapter_desc ?>" width="1000" height="720"></iframe> 

