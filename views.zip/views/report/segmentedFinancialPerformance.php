
<iframe src="http://<?= $_SERVER['SERVER_NAME'] ?>/reportapp/SegFinancialPerformance?vote_code=<?= $vote_code ?>&curr_fiscal_yr=<?= $curr_fiscal_yr ?>" width="1000" height="720"></iframe> 
