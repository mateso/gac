
<iframe src="http://<?= $_SERVER['SERVER_NAME'] ?>/reportapp/ConsolidationStatus?status=<?= $status ?>&curr_fiscal_yr=<?= $curr_fiscal_yr ?>" width="1000" height="720"></iframe> 

