
<iframe src="http://<?= $_SERVER['SERVER_NAME'] ?>/reportapp/EntityList?SubSectorDescription=<?= $SubSectorDescription ?>" width="1000" height="720"></iframe> 

